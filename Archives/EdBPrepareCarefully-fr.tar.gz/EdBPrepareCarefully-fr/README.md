# EdBPrepareCarefully-fr

Fichiers de traduction en français du mod "EdB Prepare Carefully"

**Description** :

EdB Prepare Carefully permet de personnaliser vos colons dans RimWorld, choisir les équipements et préparer soigneusement pour l'atterrissage en catastrophe ! Vous pouvez facultativement soit utiliser un nombre de points maximum pour essayer de créer un départ équilibré, soit désactiver les limites de points pour construire le groupe de départ que vous avez toujours voulu essayer. Vous pouvez aussi sauvegarder votre configuration en tant que préréglage afin de pouvoir commencer votre jeu de la même façon plus tard.

Ce mod contient seulement les fichiers de traduction en français du mod "EdB Prepare Carefully" qui, lui-même doit être chargé séparément.

**Téléchargement** : https://github.com/b606/EdBPrepareCarefully-fr/blob/master/Archives/EdBPrepareCarefully-fr.zip , fichier .zip à décompresser dans le dossier RimWorld/Mods.

> **Auteur original** : edbmods <br>
> Lien GitHub : https://github.com/edbmods/EdBPrepareCarefully/releases/ <br>
> http://steamcommunity.com/workshop/filedetails/?id=735106432
